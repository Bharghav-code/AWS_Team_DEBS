# DashboardPage

**File:** `src/pages/DashboardPage.jsx`  
**Route:** `/dashboard`  
**Auth Required:** ✅ Yes (wrapped in `<ProtectedRoute>`)

---

## Purpose

The main hub after login. Shows key performance metrics, a list of recent campaigns, a sidebar of trending topics, and a 30-day performance area chart.

---

## Layout

```
[Dashboard heading] [Create Campaign button →]

[ Active Campaigns ] [ Total Reach ] [ Avg Engagement ] [ Budget Spent ]
        (metric cards — 4 columns, responsive grid)

┌─────────────────────────────────┬──────────────────┐
│  Recent Campaigns (list)        │  Trending        │
│  (up to 5, linked to detail)    │  (top 4 trends)  │
└─────────────────────────────────┴──────────────────┘

[ Performance (30 Days) — Area Chart ]
```

Grid: `1fr 300px` on desktop, stacks to `1fr` on mobile (`< 767px`).

---

## State

No local state. All data comes from hooks.

---

## Hooks Used

| Hook | Data | Used For |
|---|---|---|
| `useAuth()` | `user` | Display `user.name` in welcome message |
| `useCampaigns()` | `{ data, isLoading }` | Campaign list + metrics |
| `useTrends()` | `{ data, isLoading }` | Trending panel |

---

## Derived Metrics (computed from campaign data)

| Metric | Calculation |
|---|---|
| Active Campaigns | `campaigns.filter(c => c.status === 'active').length` |
| Total Reach | `sum of c.reach` across all campaigns |
| Avg Engagement | `sum of c.engagement / campaigns.length` |
| Budget Spent | `sum of c.spent` across all campaigns |

---

## Static Performance Chart Data

Hardcoded weekly data (not from API):
```js
const performanceData = [
  { name: 'Week 1', reach: 12000, engagement: 450 },
  { name: 'Week 2', reach: 19000, engagement: 780 },
  { name: 'Week 3', reach: 28000, engagement: 1200 },
  { name: 'Week 4', reach: 35000, engagement: 1580 },
];
```

---

## Campaign Status Icons

```js
const statusIcons = {
  active:    { icon: '●', color: 'var(--color-success)' },
  paused:    { icon: '⏸', color: 'var(--color-warning)' },
  draft:     { icon: '📝', color: 'var(--color-text-muted)' },
  completed: { icon: '✓',  color: 'var(--color-professional-blue)' },
};
```

---

## Components Used

| Component | Purpose |
|---|---|
| `Chart` | Area chart for 30-day performance |
| `MetricSkeleton` | Loading placeholder for metric cards |
| `CardSkeleton` | Loading placeholder for campaign/trend lists |

---

## Loading States

- While `campaignsLoading`: renders `[MetricSkeleton × 4]` instead of metric cards, `<CardSkeleton>` in campaign list
- While `trendsLoading`: `<CardSkeleton>` in trending panel

---

## Empty State

If `campaigns.length === 0`:
> "No campaigns yet. Create your first campaign!"

---

## Campaign List Item

Each campaign renders as a `<Link to={/campaigns/${id}}>` styled as a flex row:
- Left: campaign name (`c.name || c.campaignName || 'Untitled'`)
- Right: status icon + status label

---

## Navigation

| Element | Action |
|---|---|
| "Create Campaign" button (`id="btn-generate-campaign"`) | → `/campaigns/create` |
| Each campaign row | → `/campaigns/:id` |

---

## Recreating This Page

```jsx
import { Link } from 'react-router-dom';
import { PlusCircle, TrendingUp, Pause, FileText, Activity, Users, BarChart3, DollarSign } from 'lucide-react';
import { useCampaigns } from '../hooks/useCampaigns';
import { useTrends } from '../hooks/useTrends';
import { useAuth } from '../hooks/useAuth';
import Chart from '../components/common/Chart';
import { MetricSkeleton, CardSkeleton } from '../components/common/LoadingSkeleton';
import { formatCurrency, formatNumber, formatPercentage } from '../utils/formatters';
import { ROUTES, CAMPAIGN_STATUS } from '../utils/constants';
```
