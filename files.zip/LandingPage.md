# LandingPage

**File:** `src/pages/LandingPage.jsx`  
**Route:** `/`  
**Auth Required:** No (public)

---

## Purpose

The public-facing marketing/home page. Introduces the Virale platform, showcases features, shows live carousels of influencers and trending topics, and drives users toward registration.

---

## Sections (top to bottom)

### 1. Hero Section
- Full-width gradient background (`var(--gradient-hero)`)
- Headline: *"Go Viral with Bharat Brands"* in brass color (`#CF9D7B`)
- Subheadline describing AI-powered campaign creation
- **CTA button** → links to `/register` (`id="btn-get-started"`)

### 2. Features Section
Three cards in a responsive grid (`auto-fit, minmax(280px, 1fr)`):

| Icon | Title | Description |
|---|---|---|
| TrendingUp | Trend Discovery | AI trend detection with real-time alignment scoring |
| Users | Influencer Matching | Smart algorithm to find influencers within budget |
| Sparkles | AI Content Adaptation | Adapt content for local markets via Amazon Bedrock |

### 3. Featured Influencers Carousel
- Uses `<CardCarousel>` with `MOCK_INFLUENCERS` data
- Auto-advances every **4000ms**
- Each card shows: avatar placeholder / image, name, handle, category badge, followers count, engagement rate
- Renderer: `renderInfluencerMini(inf, index, isActive)`

### 4. Social Proof Stats Bar
- Background: `var(--color-light-gray)`
- Three stats displayed horizontally (wraps on mobile):
  - **10K+** Campaigns
  - **500+** Influencers
  - **50+** Markets

### 5. Trending Now Carousel
- Uses `<CardCarousel>` with `MOCK_TRENDS` data
- Auto-advances every **5000ms**
- Each card shows: image/placeholder, badge label, name, brand alignment progress bar + percentage
- Renderer: `renderTrendMini(trend, index, isActive)`

### 6. CTA Section
- Globe icon (teal accent)
- "Ready to go viral?" headline
- Secondary CTA button → `/register` ("Start Free Trial")
- Style: coffee background, brass text

---

## Components Used

| Component | Import |
|---|---|
| `CardCarousel` | `../components/common/CardCarousel` |
| `Link` | `react-router-dom` |
| Icons: `ArrowRight, TrendingUp, Users, Sparkles, Zap, Globe, User, Image` | `lucide-react` |

---

## Data Dependencies

| Source | Variable | Used For |
|---|---|---|
| `../data/mockData` | `MOCK_INFLUENCERS` | Influencer carousel |
| `../data/mockData` | `MOCK_TRENDS` | Trends carousel |
| `../utils/constants` | `ROUTES` | Link hrefs |
| `../utils/formatters` | `formatNumber, formatPercentage` | Influencer card stats |

---

## Styling Notes

- All styles are inline (no CSS module for this page)
- Uses CSS variables throughout: `--gradient-hero`, `--color-brass`, `--space-*`, `--radius-*`, etc.
- Hero font scales with `clamp(28px, 5vw, 48px)` for responsiveness
- Cards use global `.card` class

---

## Recreating This Page

```jsx
// Minimum imports needed
import { Link } from 'react-router-dom';
import { ArrowRight, TrendingUp, Users, Sparkles, Zap, Globe, User, Image } from 'lucide-react';
import { ROUTES } from '../utils/constants';
import { MOCK_INFLUENCERS, MOCK_TRENDS } from '../data/mockData';
import CardCarousel from '../components/common/CardCarousel';
import { formatNumber, formatPercentage } from '../utils/formatters';
```

Key data arrays defined locally in the file:
- `features` — array of `{ icon, title, description }` (3 items)
- `stats` — array of `{ value, label }` (3 items)
- `renderInfluencerMini(inf, _i, isActive)` — card renderer fn
- `renderTrendMini(trend, _i, isActive)` — card renderer fn
