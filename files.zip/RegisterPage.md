# RegisterPage

**File:** `src/pages/RegisterPage.jsx`  
**Route:** `/register`  
**Auth Required:** No (public)

---

## Purpose

Creates a new user account. Has a two-step flow: **Register** → **Confirm email** (though in demo mode the confirm step is skipped and the user is sent directly to `/login` after registration).

---

## Layout

Centered card (same structure as LoginPage). Max width: **420px**.

```
[UserPlus icon]
"Create account" | "Verify email" (changes per step)
subtitle text

--- Step: register ---
[ Full Name input ]
[ Username input ]
[ Password input ]
[ Create Account button ]
[ "Already have an account? Sign in" link ]

--- Step: confirm ---
[ Verification Code input ]
[ Verify Email button ]
```

---

## State

| Variable | Type | Default | Purpose |
|---|---|---|---|
| `name` | `string` | `''` | Full name |
| `email` | `string` | `''` | Username |
| `password` | `string` | `''` | Password |
| `confirmCode` | `string` | `''` | Email verification code |
| `step` | `'register' \| 'confirm'` | `'register'` | Controls which form to show |
| `error` | `string` | `''` | Inline error |
| `loading` | `boolean` | `false` | Loading state |

---

## Step 1: Register (`handleRegister`)

1. Validate: name ≥ 2 chars, email non-empty, password non-empty
2. Call `register(email, password, name)` from `useAuth()`
3. On success → **in demo mode:** skip verification → navigate to `/login`
4. On error → show error message

> **Note:** The `setStep('confirm')` path exists in code but is commented out / skipped in demo. To enable email confirmation, change `navigate(ROUTES.LOGIN)` to `setStep('confirm')`.

---

## Step 2: Confirm (`handleConfirm`)

1. Call `confirm(email, confirmCode)` from `useAuth()`
2. On success → navigate to `/login`
3. On error → show error message

---

## Components & Hooks Used

| Import | Purpose |
|---|---|
| `useAuth()` | Provides `register(email, password, name)` and `confirm(email, code)` |
| `useNavigate()` | Redirect after registration |
| `Link` | "Sign in" link |
| `UserPlus, Loader2` (lucide-react) | Icon + spinner |

---

## Navigation Links

| Action | Route |
|---|---|
| After successful register (demo) | `/login` |
| After email confirm | `/login` |
| "Sign in" link | `/login` |

---

## Re-enabling Email Confirmation

In `handleRegister`, replace:
```js
navigate(ROUTES.LOGIN);
```
with:
```js
setStep('confirm');
```
This will show the confirmation code form after successful registration.

---

## Recreating This Page

```jsx
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { UserPlus, Loader2 } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { ROUTES } from '../utils/constants';

// State: name, email, password, confirmCode, step='register', error, loading
// Step 1: useAuth().register(email, password, name) → navigate('/login')
// Step 2: useAuth().confirm(email, confirmCode) → navigate('/login')
```
