# LoginPage

**File:** `src/pages/LoginPage.jsx`  
**Route:** `/login`  
**Auth Required:** No (public)

---

## Purpose

Authenticates an existing user. On success, navigates to `/dashboard`. In demo mode, pre-fills credentials (`divisha` / `divisha`).

---

## Layout

Centered card on the page (`minHeight: calc(100vh - nav - footer)`).  
Max width: **420px**.

```
[LogIn icon]
"Welcome back"
"Sign in to your Virale account"

[ Demo credentials hint banner ]
[ Username input ]
[ Password input ]
[ Sign In button ]
[ "Don't have an account? Sign up" link ]
```

---

## State

| Variable | Type | Default | Purpose |
|---|---|---|---|
| `email` | `string` | `'divisha'` | Username input value |
| `password` | `string` | `'divisha'` | Password input value |
| `error` | `string` | `''` | Inline error message |
| `loading` | `boolean` | `false` | Disables button / shows spinner |

---

## Form Logic (`handleSubmit`)

1. Prevent default form submission
2. Validate: both fields must be non-empty → sets `error` if not
3. Set `loading = true`
4. Call `login(email, password)` from `useAuth()`
5. On success → `navigate(ROUTES.DASHBOARD)`
6. On error → display `err.message` or fallback error text
7. Always: `loading = false` in `finally`

---

## Components & Hooks Used

| Import | Purpose |
|---|---|
| `useAuth()` | Provides `login` function (AWS Cognito) |
| `useNavigate()` | Redirect after login |
| `Link` | "Sign up" navigation |
| `validateEmail, validatePassword` | Imported from validators but **not actively used** (validation is just empty-check) |
| `LogIn, Loader2` (lucide-react) | Icon + loading spinner |

---

## Demo Credentials Banner

A styled hint box displays inside the form card:
```
Demo credentials: divisha / divisha
```
Background: `var(--color-jet)`, text: `var(--color-brass)`

---

## Error Display

Red-tinted box (`rgba(114, 75, 57, 0.15)`) with `var(--color-error)` text. Appears above inputs when `error` is set.

---

## Loading State

Button shows `<Loader2>` spinning icon + "Signing in..." text. Button is `disabled` during load.

Spinner CSS: `@keyframes spin` injected inline via `<style>` tag.

---

## Navigation Links

| Action | Route |
|---|---|
| After successful login | `/dashboard` |
| "Sign up" link | `/register` |

---

## Recreating This Page

```jsx
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LogIn, Loader2 } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { ROUTES } from '../utils/constants';

// State: email (default 'divisha'), password (default 'divisha'), error, loading
// On submit: call useAuth().login(email, password) → navigate to dashboard
```
