# CreateCampaignPage

**File:** `src/pages/CreateCampaignPage.jsx`  
**Route:** `/campaigns/create`  
**Auth Required:** ✅ Yes

---

## Purpose

A 5-step wizard for creating a new campaign. Each step is a separate component rendered inside a card. Navigation (Back/Next/Launch) is handled at the page level; step data is persisted in `CampaignContext`.

---

## Layout

```
"Create Campaign"

[ WizardStepper — step indicators 1–5 ]

┌─────────────────────────────────────────┐
│  <StepComponent />  (changes per step)  │
└─────────────────────────────────────────┘

[ ← Back ]                    [ Next → ]
                     (or)     [ 🚀 Launch Campaign ]  (on step 5)
```

---

## Wizard Steps

| Step | Component | Key Fields |
|---|---|---|
| 1 | `StepBudgetGoals` | budget, campaignName, goals |
| 2 | `StepTargetMarket` | market (Indian state), category |
| 3 | `StepContent` | content text, AI adaptation via Bedrock |
| 4 | `StepInfluencers` | selectedInfluencers (array of IDs) |
| 5 | `StepReview` | Read-only summary + launch |

---

## Context Consumed (`CampaignContext`)

| Value | Type | Purpose |
|---|---|---|
| `draft` | object | Full wizard state (see below) |
| `nextStep()` | fn | Advance `draft.step` by 1 (max 5) |
| `prevStep()` | fn | Decrease `draft.step` by 1 (min 1) |
| `saveDraft()` | fn | Persists draft to `localStorage` |
| `resetDraft()` | fn | Clears draft + localStorage |

### Draft Object Shape
```js
{
  step: 1,                    // Current wizard step (1–5)
  budget: 25000,              // ₹ amount
  goals: '',                  // Campaign goal text
  market: '',                 // Indian state ID (e.g. 'maharashtra')
  category: '',               // e.g. 'Fitness'
  content: '',                // Ad copy / campaign message
  selectedInfluencers: [],    // Array of influencer IDs
  campaignName: '',           // Campaign display name
}
```

---

## Launch Logic (`handleLaunch`)

Called when user clicks "Launch Campaign" on step 5:
1. Calls `createMutation.mutate(draft)` via `useCreateCampaign()` hook
2. On success:
   - `resetDraft()` — clear wizard state
   - Navigate to `/dashboard`

---

## Navigation Buttons

| Button | Condition | Action |
|---|---|---|
| ← Back | Always shown; disabled if `step === 1` | `saveDraft()` + `prevStep()` |
| Next → | Shown if `step < 5` | `saveDraft()` + `nextStep()` |
| 🚀 Launch | Shown if `step === 5` | `handleLaunch()` |

---

## Step Components Detail

### Step 1 — StepBudgetGoals (`src/components/wizard/StepBudgetGoals.jsx`)
- **BudgetSlider**: snap-to-step slider from ₹5K → ₹1L
- **Campaign Name**: text input → `draft.campaignName`
- **Campaign Goals**: textarea → `draft.goals`

### Step 2 — StepTargetMarket (`src/components/wizard/StepTargetMarket.jsx`)
- Shows selected budget as a read-only chip (formatted as ₹XK/₹XL)
- **State**: `<select>` from all 29 MARKETS → `draft.market`
- **Category**: clickable chip buttons from CATEGORIES array → `draft.category`

### Step 3 — StepContent (`src/components/wizard/StepContent.jsx`)
- **Content textarea** → `draft.content`
- **AI Adapt button**: calls `useContentAdaptation().mutate({ content, market, category })`
  - Disabled if content is empty or mutation is pending
  - Shows spinner during loading
  - On success: displays `adapted.adaptedContent` in a result card

### Step 4 — StepInfluencers (`src/components/wizard/StepInfluencers.jsx`)
- Fetches influencers filtered by `draft.market` via `useInfluencers()`
- Displays influencers as `<InfluencerCard>` in a grid
- Click to toggle selection (adds/removes from `draft.selectedInfluencers`)
- Selected cards get a blue border highlight (`var(--color-professional-blue)`)
- Shows count of selected influencers at bottom

### Step 5 — StepReview (`src/components/wizard/StepReview.jsx`)
- Read-only summary of all draft fields:
  - Campaign Name, Budget, Goals, Target Market, Category, Selected Influencers count
- Optional content preview section (if `draft.content` is non-empty)

---

## Hooks Used

| Hook | Purpose |
|---|---|
| `useContext(CampaignContext)` | All wizard state |
| `useCreateCampaign()` | POST campaign to API on launch |
| `useNavigate()` | Redirect to dashboard after launch |

---

## Recreating This Page

```jsx
import { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Rocket, Loader2 } from 'lucide-react';
import { CampaignContext } from '../context/CampaignContext';
import { useCreateCampaign } from '../hooks/useCampaigns';
import WizardStepper from '../components/wizard/WizardStepper';
import StepBudgetGoals from '../components/wizard/StepBudgetGoals';
import StepTargetMarket from '../components/wizard/StepTargetMarket';
import StepContent from '../components/wizard/StepContent';
import StepInfluencers from '../components/wizard/StepInfluencers';
import StepReview from '../components/wizard/StepReview';
import { ROUTES } from '../utils/constants';

// Map step number → component
const steps = { 1: StepBudgetGoals, 2: StepTargetMarket, 3: StepContent, 4: StepInfluencers, 5: StepReview };
```
