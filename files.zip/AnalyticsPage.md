# AnalyticsPage

**File:** `src/pages/AnalyticsPage.jsx`  
**Route:** `/analytics`  
**Auth Required:** ✅ Yes

---

## Purpose

Displays aggregate analytics across all campaigns — total reach, engagement, conversions, and ROI — with a time-period selector and a downloadable area chart.

---

## Layout

```
"Analytics"                    [ Period select ] [ Export button ]

[ Total Reach ] [ Avg Engagement ] [ Conversions ] [ ROI ]
    (4 metric cards, auto-fit minmax 180px)

┌─────────────────────────────────────────────────────┐
│  Performance Overview — Area Chart                  │
│  (lines: reach, engagement, conversions)            │
└─────────────────────────────────────────────────────┘
```

---

## State

| Variable | Type | Default | Purpose |
|---|---|---|---|
| `period` | `string` | `'6months'` | Time range for analytics query |

Period options:
- `7days` → Last 7 Days
- `30days` → Last 30 Days
- `6months` → Last 6 Months
- `1year` → Last Year

---

## Data Fetching

```js
const { data, isLoading } = useAnalytics({ period });
const analyticsData = data || {};
```

Hook re-fetches whenever `period` changes.

---

## Metric Cards

Fallback values are shown if the API returns nothing:

| Label | API Field | Fallback |
|---|---|---|
| Total Reach | `analyticsData.totalReach` | `456000` |
| Avg Engagement | `analyticsData.avgEngagement` | `8.2` |
| Conversions | `analyticsData.conversions` | `1255` |
| ROI | `analyticsData.roi` | `340` (%) |

---

## Loading State

While `isLoading === true`, renders `[MetricSkeleton × 4]` instead of metric cards.

---

## Performance Chart

- **Type:** Area chart
- **Data:** `analyticsData.timeline` (from API) or fallback `sampleData`:
```js
const sampleData = [
  { name: 'Jan', reach: 45000, engagement: 3200, conversions: 120 },
  { name: 'Feb', reach: 52000, engagement: 3800, conversions: 145 },
  { name: 'Mar', reach: 61000, engagement: 4500, conversions: 180 },
  { name: 'Apr', reach: 78000, engagement: 5200, conversions: 210 },
  { name: 'May', reach: 95000, engagement: 6100, conversions: 260 },
  { name: 'Jun', reach: 125000, engagement: 8200, conversions: 340 },
];
```
- **Data keys:** `['reach', 'engagement', 'conversions']`
- **Height:** 350px

---

## Export Feature

```js
const handleExport = async () => {
  try {
    await exportAnalytics({ period });
  } catch {
    // Silently handles errors
  }
};
```

Calls `exportAnalytics` from `../services/analyticsService`. No error UI shown on failure.

Export button style:
- Border: `1px solid var(--color-border-medium)`
- Background: `var(--color-white)`
- Icon: `<Download size={18} />`

---

## Hooks Used

| Hook | Data |
|---|---|
| `useAnalytics({ period })` | Aggregate analytics data |

---

## Services Used

| Function | File | Purpose |
|---|---|---|
| `exportAnalytics({ period })` | `../services/analyticsService` | Trigger data export |

---

## Components Used

| Component | Purpose |
|---|---|
| `Chart` | Area chart for performance timeline |
| `MetricSkeleton` | Loading placeholder for metric cards |

---

## Formatters Used

| Function | Applied To |
|---|---|
| `formatNumber()` | Total Reach, Conversions |
| `formatPercentage()` | Avg Engagement, ROI |
| `formatCurrency()` | Not used here (but imported in same project) |

---

## Recreating This Page

```jsx
import { useState } from 'react';
import { Download } from 'lucide-react';
import { useAnalytics } from '../hooks/useAnalytics';
import Chart from '../components/common/Chart';
import { MetricSkeleton } from '../components/common/LoadingSkeleton';
import { formatNumber, formatPercentage } from '../utils/formatters';
import { exportAnalytics } from '../services/analyticsService';

// State: period='6months'
// Metrics with fallbacks: totalReach→456000, avgEngagement→8.2, conversions→1255, roi→340
// Chart uses analyticsData.timeline or sampleData fallback
```
