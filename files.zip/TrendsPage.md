# TrendsPage

**File:** `src/pages/TrendsPage.jsx`  
**Route:** `/trends`  
**Auth Required:** ✅ Yes

---

## Purpose

Lets users explore trending topics across Indian markets. Supports filtering by state, category, and a text search. Results are displayed as a responsive grid of `<TrendCard>` components.

---

## Layout

```
"Trend Explorer"

[ 🔍 Search input ] [ State select ] [ Category select ]

┌────────────┬────────────┬────────────┐
│ TrendCard  │ TrendCard  │ TrendCard  │
├────────────┼────────────┼────────────┤
│ TrendCard  │ TrendCard  │ TrendCard  │
└────────────┴────────────┴────────────┘
   (auto-fill minmax 300px grid)

  Empty state: Filter icon + "No trends found..."
  Loading state: 6× CardSkeleton
```

---

## State

| Variable | Type | Default | Purpose |
|---|---|---|---|
| `market` | `string` | `''` | Selected state ID for API filter |
| `category` | `string` | `''` | Selected category for API filter |
| `search` | `string` | `''` | Client-side text search |

---

## Data Fetching

```js
const params = {};
if (market) params.market = market;
if (category) params.category = category;

const { data, isLoading } = useTrends(params);
const trends = Array.isArray(data) ? data : data?.trends || [];
```

Market and category filters are sent as API params. Search is applied **client-side** after fetching.

---

## Client-side Search Filter

```js
const filtered = trends.filter((t) => {
  if (search) {
    const q = search.toLowerCase();
    return t.name?.toLowerCase().includes(q) || t.badge?.toLowerCase().includes(q);
  }
  return true;
});
```

Searches both `trend.name` and `trend.badge`.

---

## Filters UI

### Search Input
- Icon: `<Search>` absolutely positioned inside input padding
- Placeholder: "Search trends..."

### State Select
- Options from `MARKETS` constant (29 Indian states)
- Style: `background: var(--color-jungle-green)`, `color: var(--color-brass)`
- First option: "All States" (value `""`)

### Category Select
- Options from `CATEGORIES` constant (8 categories)
- First option: "All Categories" (value `""`)
- Width: `flex: 0 0 160px`

---

## Loading State

6× `<CardSkeleton>` in the same grid layout.

---

## Empty State

Shown when `filtered.length === 0`:
- `<Filter>` icon (48px, 50% opacity)
- Text: "No trends found. Try adjusting your filters."

---

## TrendCard Props

```jsx
<TrendCard key={trend.id || i} trend={trend} index={i} />
```

`trend` object typically contains:
- `id` — unique identifier
- `name` — trend name
- `badge` — category/label tag
- `alignmentPercentage` — brand alignment score (0–100)
- `imageUrl` — optional image

---

## Hooks Used

| Hook | Data |
|---|---|
| `useTrends(params)` | Trend list from API |

---

## Constants Used

| Constant | Source |
|---|---|
| `MARKETS` | `../utils/constants` — array of `{ id, name }` |
| `CATEGORIES` | `../utils/constants` — string array |

---

## Components Used

| Component | Purpose |
|---|---|
| `TrendCard` | Individual trend display card |
| `CardSkeleton` | Loading placeholder |

---

## Recreating This Page

```jsx
import { useState } from 'react';
import { Search, Filter } from 'lucide-react';
import { useTrends } from '../hooks/useTrends';
import TrendCard from '../components/common/TrendCard';
import { CardSkeleton } from '../components/common/LoadingSkeleton';
import { MARKETS, CATEGORIES } from '../utils/constants';

// State: market='', category='', search=''
// API params: { market, category } (omit empty strings)
// Client filter: search on trend.name and trend.badge
```
