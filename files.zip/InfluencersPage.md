# InfluencersPage

**File:** `src/pages/InfluencersPage.jsx`  
**Route:** `/influencers`  
**Auth Required:** ✅ Yes

---

## Purpose

A marketplace for browsing influencers. Users can filter by state, search by handle/niche, and set a maximum budget using a slider. Results display as a responsive grid of `<InfluencerCard>` components.

---

## Layout

```
"Influencer Marketplace"

┌─ Filter Card ────────────────────────────────────────┐
│ [ 🔍 Search input ]    [ State select ]              │
│ [ BudgetSlider — max budget filter ]                 │
└──────────────────────────────────────────────────────┘

┌────────────────┬────────────────┬────────────────┐
│ InfluencerCard │ InfluencerCard │ InfluencerCard │
├────────────────┼────────────────┼────────────────┤
│ InfluencerCard │ InfluencerCard │ InfluencerCard │
└────────────────┴────────────────┴────────────────┘
   (auto-fill minmax 260px grid)

  Loading state: 6× CardSkeleton
  Empty state: SlidersHorizontal icon + message
```

---

## State

| Variable | Type | Default | Purpose |
|---|---|---|---|
| `market` | `string` | `''` | State filter sent to API |
| `search` | `string` | `''` | Client-side text search |
| `maxBudget` | `number` | `BUDGET.MAX` (100000) | Max cost filter |

---

## Data Fetching

```js
const params = {};
if (market) params.market = market;

const { data, isLoading } = useInfluencers(params);
const influencers = Array.isArray(data) ? data : data?.influencers || [];
```

State filter is sent to the API. Budget and search filters are applied **client-side**.

---

## Client-side Filtering

```js
const filtered = influencers.filter((inf) => {
  if (inf.cost > maxBudget) return false;      // Budget filter
  if (search) {
    const q = search.toLowerCase();
    return inf.handle?.toLowerCase().includes(q)
        || inf.niche?.toLowerCase().includes(q);
  }
  return true;
});
```

Filters by `inf.cost <= maxBudget` AND optionally searches `inf.handle` and `inf.niche`.

---

## Filters UI

### Search Input
- `<Search>` icon inside left padding
- Placeholder: "Search influencers..."
- Searches: `inf.handle`, `inf.niche`

### State Select
- Options from `MARKETS` constant
- Style: `background: var(--color-jungle-green)`, `color: var(--color-brass)`
- "All States" default option

### BudgetSlider
```jsx
<BudgetSlider steps={BUDGET.STEPS} value={maxBudget} onChange={setMaxBudget} />
```
- BUDGET.STEPS: `[5000, 20000, 35000, 50000, 65000, 80000, 95000, 100000]`
- Controls maximum cost of displayed influencers

---

## InfluencerCard Props

```jsx
<InfluencerCard
  key={inf.id || i}
  influencer={inf}
  isWithinBudget={inf.cost <= maxBudget}
  index={i}
/>
```

`influencer` object typically contains:
- `id`
- `name`
- `handle` — @username
- `category` / `niche`
- `followers` — number
- `engagementRate` — decimal (e.g. 0.045 = 4.5%)
- `cost` — ₹ per campaign
- `imageUrl` — optional avatar

`isWithinBudget` — passed down for visual indication inside the card.

---

## Loading State

6× `<CardSkeleton>` in the same grid layout.

---

## Empty State

Shown when `filtered.length === 0`:
- `<SlidersHorizontal>` icon (48px, 50% opacity)
- Text: "No influencers found. Try adjusting your filters."

---

## Hooks Used

| Hook | Data |
|---|---|
| `useInfluencers(params)` | Influencer list from API |

---

## Constants Used

| Constant | Value |
|---|---|
| `MARKETS` | Array of `{ id, name }` for all Indian states |
| `BUDGET.MAX` | `100000` (₹1,00,000) |
| `BUDGET.STEPS` | `[5000, 20000, 35000, 50000, 65000, 80000, 95000, 100000]` |

---

## Components Used

| Component | Purpose |
|---|---|
| `InfluencerCard` | Individual influencer display |
| `BudgetSlider` | Step-based budget range selector |
| `CardSkeleton` | Loading placeholder |

---

## Recreating This Page

```jsx
import { useState } from 'react';
import { Search, SlidersHorizontal } from 'lucide-react';
import { useInfluencers } from '../hooks/useInfluencers';
import InfluencerCard from '../components/common/InfluencerCard';
import BudgetSlider from '../components/common/BudgetSlider';
import { CardSkeleton } from '../components/common/LoadingSkeleton';
import { MARKETS, BUDGET } from '../utils/constants';

// State: market='', search='', maxBudget=BUDGET.MAX
// Client filter: inf.cost <= maxBudget AND (inf.handle | inf.niche).includes(search)
```
