# Virale — Master Documentation

> **Virale** is an AI-powered influencer marketing platform for Indian brands ("Bharat Brands") to discover trends, match influencers, create campaigns, and adapt content for regional markets using Amazon Bedrock.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | React 18 (Vite) |
| Routing | React Router v6 |
| State / Data | @tanstack/react-query |
| Auth | AWS Cognito (via custom `useAuth` hook) |
| AI Content | Amazon Bedrock (via `contentService`) |
| Styling | CSS Modules + CSS Variables (no Tailwind) |
| Icons | lucide-react |

---

## Project Structure

```
src/
├── pages/               # One file per route/page
│   ├── LandingPage.jsx
│   ├── LoginPage.jsx
│   ├── RegisterPage.jsx
│   ├── DashboardPage.jsx
│   ├── CreateCampaignPage.jsx
│   ├── CampaignDetailsPage.jsx
│   ├── TrendsPage.jsx
│   ├── InfluencersPage.jsx
│   └── AnalyticsPage.jsx
├── components/
│   ├── layout/          # Navigation, Header, Footer
│   ├── common/          # Reusable UI (Chart, Modal, Cards, etc.)
│   ├── wizard/          # 5-step campaign creation wizard
│   └── ProtectedRoute.jsx
├── context/
│   ├── AuthContext.jsx
│   ├── CampaignContext.jsx
│   └── ThemeContext.jsx
├── hooks/               # Custom hooks wrapping react-query
├── services/            # API calls (auth, campaigns, trends, etc.)
├── utils/
│   ├── constants.js     # Routes, markets, categories, budget config
│   ├── formatters.js    # Currency, number, date formatting
│   └── validators.js    # Form validation helpers
├── styles/
│   ├── global.css
│   ├── variables.css    # All CSS custom properties
│   └── components/      # Per-component CSS modules
├── data/
│   └── mockData.js      # MOCK_INFLUENCERS, MOCK_TRENDS
└── App.jsx              # Root: providers + BrowserRouter + routes
```

---

## Routes

| Path | Page | Auth Required |
|---|---|---|
| `/` | LandingPage | No |
| `/login` | LoginPage | No |
| `/register` | RegisterPage | No |
| `/dashboard` | DashboardPage | ✅ Yes |
| `/campaigns/create` | CreateCampaignPage | ✅ Yes |
| `/campaigns/:id` | CampaignDetailsPage | ✅ Yes |
| `/trends` | TrendsPage | ✅ Yes |
| `/influencers` | InfluencersPage | ✅ Yes |
| `/analytics` | AnalyticsPage | ✅ Yes |
| `*` | Redirects to `/` | — |

---

## Environment Variables (`.env`)

```env
VITE_API_URL=https://your-api-gateway-url
VITE_COGNITO_USER_POOL_ID=us-east-1_XXXXXXXXX
VITE_COGNITO_CLIENT_ID=xxxxxxxxxxxxxxxxxxxxxx
VITE_REGION=us-east-1
```

---

## Setup & Run Locally

```bash
# 1. Install dependencies
npm install

# 2. Create .env file (see above)

# 3. Start dev server
npm run dev

# 4. Build for production
npm run build
```

---

## Demo Credentials

The app ships with demo mode. Use:
- **Username:** `divisha`
- **Password:** `divisha`

---

## Key Constants (`src/utils/constants.js`)

- **BUDGET:** Min ₹5,000 / Max ₹1,00,000. Steps: `[5000, 20000, 35000, 50000, 65000, 80000, 95000, 100000]`
- **MARKETS:** All 28 Indian states + J&K (IDs are kebab-case slugs, e.g. `maharashtra`, `tamil-nadu`)
- **CATEGORIES:** Fitness, Beauty, Technology, Food, Travel, Fashion, Health, Entertainment
- **CAMPAIGN_STATUS:** `active`, `paused`, `draft`, `completed`
- **QUERY_CONFIG:** staleTime 5min, cacheTime 10min, retry 2

---

## Pages Quick Reference

| File | Description |
|---|---|
| `LandingPage.md` | Public hero/marketing page |
| `LoginPage.md` | Login form |
| `RegisterPage.md` | Registration + email verify |
| `DashboardPage.md` | Main metrics hub |
| `CreateCampaignPage.md` | 5-step wizard |
| `CampaignDetailsPage.md` | Per-campaign detail view |
| `TrendsPage.md` | Trend explorer + filters |
| `InfluencersPage.md` | Influencer marketplace |
| `AnalyticsPage.md` | Analytics charts + export |
