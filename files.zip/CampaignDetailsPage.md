# CampaignDetailsPage

**File:** `src/pages/CampaignDetailsPage.jsx`  
**Route:** `/campaigns/:id`  
**Auth Required:** ✅ Yes

---

## Purpose

Displays detailed information about a single campaign — its metrics, a performance line chart, and campaign attributes (goals, market, category). Campaign `id` comes from the URL param.

---

## Layout

```
← Back to Dashboard

[Campaign Name]   [status badge]   [created date]

[ Budget ] [ Reach ] [ Engagement ] [ Spent ]
      (4-column responsive metric cards)

[ Performance Chart — Line Chart ]

[ Details card — Goals / Market / Category ]
  (only shown if any of these fields exist)
```

---

## URL Parameter

```js
const { id } = useParams();
```

Used to fetch the specific campaign and its analytics.

---

## Hooks Used

| Hook | Data | Source |
|---|---|---|
| `useCampaign(id)` | `{ data: campaign, isLoading }` | `../hooks/useCampaigns` |
| `useCampaignAnalytics(id)` | `{ data: analytics }` | `../hooks/useAnalytics` |

---

## Loading State

While `isLoading === true`, renders `<LoadingSkeleton lines={8} />` inside a max-width container.

---

## Campaign Data Mapping

The component handles both API response shapes:
- `c.name` or `c.campaignName` → displayed as heading
- `c.id` or `c.campaignId` → used for routing
- `c.status` → shown as colored badge
- `c.createdAt` → formatted with `formatDate()`
- `c.budget`, `c.reach`, `c.engagement`, `c.spent` → metric cards

---

## Status Badge Style

```
active    → background: rgba(207,157,123, 0.15), color: var(--color-success)
other     → background: rgba(114, 75, 57, 0.2),  color: var(--color-warning)
```

---

## Metric Cards

Four cards in `auto-fit, minmax(180px, 1fr)` grid:

| Label | Value | Formatter |
|---|---|---|
| Budget | `c.budget` | `formatCurrencyFull()` |
| Reach | `c.reach` | `formatNumber()` |
| Engagement | `c.engagement` | `formatPercentage()` |
| Spent | `c.spent` | `formatCurrencyFull()` |

---

## Performance Chart

- **Type:** Line chart
- **Data:** `analytics?.daily` (from API) or fallback hardcoded data:
```js
[
  { name: 'Day 1', reach: 2000, engagement: 120 },
  { name: 'Day 2', reach: 3500, engagement: 210 },
  { name: 'Day 3', reach: 5200, engagement: 340 },
  { name: 'Day 4', reach: 7100, engagement: 480 },
  { name: 'Day 5', reach: 8800, engagement: 590 },
]
```
- **Data keys:** `['reach', 'engagement']`
- **Height:** 300px

---

## Details Section

Conditionally rendered only if at least one of `c.goals`, `c.market`, or `c.category` exists:
```
Goals: <value>
Market: <value>
Category: <value>
```

---

## Components Used

| Component | Purpose |
|---|---|
| `Chart` | Line chart for daily performance |
| `LoadingSkeleton` | Full-page loading skeleton |

---

## Navigation

| Element | Destination |
|---|---|
| ← Back to Dashboard | `/dashboard` |

---

## Recreating This Page

```jsx
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Activity } from 'lucide-react';
import { useCampaign } from '../hooks/useCampaigns';
import { useCampaignAnalytics } from '../hooks/useAnalytics';
import Chart from '../components/common/Chart';
import LoadingSkeleton from '../components/common/LoadingSkeleton';
import { formatCurrencyFull, formatNumber, formatPercentage, formatDate } from '../utils/formatters';
import { ROUTES } from '../utils/constants';

// const { id } = useParams();
// const { data: campaign, isLoading } = useCampaign(id);
// const { data: analytics } = useCampaignAnalytics(id);
```
